#pragma once

#include "types.h"

void* memset(void *, int, uint64);

void* memcopy(void *copy, void *src, uint64 size);