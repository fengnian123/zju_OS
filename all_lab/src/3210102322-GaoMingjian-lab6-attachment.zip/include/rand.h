#include "types.h"

#define SEED 13
uint64 rand();
