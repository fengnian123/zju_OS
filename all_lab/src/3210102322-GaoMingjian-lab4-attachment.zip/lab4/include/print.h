#ifndef _PRINT_H
#define _PRINT_H
#include "types.h"
void puts(char *s);
void puti(int x);
void put64(uint64 x);

#endif
